def f(x):
    return 4 * math.exp(-0.5 * x) - x
def f_turev(x):
    return (-2) * math.exp(-0.5 * x) - 1

def newton_raphson(bas, son):
    x = bas
    for i in range(son):
        x -= f(x) / f_turev(x)
    return x

import math
bas = 2
son = 4
root = newton_raphson(bas, son)
print(f"Denklemin kökü: {root:.6f}")