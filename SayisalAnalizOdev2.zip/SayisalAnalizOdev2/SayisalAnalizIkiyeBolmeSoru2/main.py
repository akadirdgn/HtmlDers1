def f(x):
    return x**3 + 4*x**2 - 10

sayi1, sayi2 = 1, 2
for i in range(4):
    kok = (sayi1 + sayi2) / 2
    f_kok = f(kok)
    if f_kok > 0:
        sayi2 = kok
    else:
        sayi1 = kok

print(f"Denklemin kökü: {kok:.6f}")