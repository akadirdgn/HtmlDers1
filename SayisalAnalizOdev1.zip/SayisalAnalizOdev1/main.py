import math
x = math.pi / 5
cosx = math.cos(x)

cosx1 = 1
cosx2 = 1 - (x ** 2) / 2

kesmeHatasi1 = abs(cosx - cosx1)
kesmeHatasi2 = abs(cosx - cosx2)

print(f"Gerçek değer: {cosx}")

print(f"Tek terimli Taylor serisi: {cosx1}")
print(f"Tek terimli taylor serisi kesme hatası: {kesmeHatasi1}")

print(f"İki terimli Taylor serisi: {cosx2}")
print(f"İki terimli taylor serisi kesme hatasi: {kesmeHatasi2}")

